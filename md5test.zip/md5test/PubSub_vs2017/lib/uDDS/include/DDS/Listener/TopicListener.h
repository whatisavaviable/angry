#pragma once

#include "DDS/Listener/DDSListener.h"

/* Nephalem ����ӿ� */
class TopicListener : public DDSListener
{

};