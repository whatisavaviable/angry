1.当前目录打开cmd。
2.执行DemoTool.exe UserDataType.idl vs2017。
3.生成PubSub_vs2017文件夹，文件内有发布和订阅的项目。
4.进入文件以vs2017打开方式打开Sub_Pub.sln项目进行编译。