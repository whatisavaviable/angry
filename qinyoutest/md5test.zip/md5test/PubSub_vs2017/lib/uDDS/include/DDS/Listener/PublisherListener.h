#pragma once
#include "DDS/Listener/DDSListener.h"

/* Nephalem ����ӿ� */
class PublisherListener : public DDSListener
{

};