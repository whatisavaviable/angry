#pragma once
#include "SEQ/Sequence.h"
#include <string>
using std::string;

typedef sequence<string> StringSeq;